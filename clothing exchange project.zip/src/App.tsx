import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { ClothingCard } from "./components/ClothingCard";
import { ListingModal } from "./components/ListingModal";
import { SwapRequests } from "./components/SwapRequests";
import { SwapModal } from "./components/SwapModal";
import { AuthPage } from "./components/AuthPage";
import { ProfilePictureModal } from "./components/ProfilePictureModal";
import { clothingItems, myItems, type ClothingItem } from "./data/clothes";

export type View = "home" | "browse" | "swaps" | "profile";

interface SwapRequest {
  id: number;
  status: "pending" | "accepted" | "declined" | "completed";
  theirItem: {
    id: number;
    title: string;
    image: string;
    owner: string;
    avatar: string;
  };
  myItem: {
    id: number;
    title: string;
    image: string;
  };
  date: string;
  message?: string;
}

interface User {
  name: string;
  email: string;
  avatar: string;
}

const initialSwapRequests: SwapRequest[] = [
  {
    id: 1,
    status: "pending",
    theirItem: {
      id: 101,
      title: "Vintage Denim Jacket",
      image: "https://images.unsplash.com/photo-1576995853080-3b6de5a87d22?w=400&h=500&fit=crop",
      owner: "Sarah Miller",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
    },
    myItem: {
      id: 201,
      title: "Summer Floral Dress",
      image: "https://images.unsplash.com/photo-1572804013309-59a88f240654?w=400&h=500&fit=crop",
    },
    date: "2 hours ago",
    message: "Would love to swap! My jacket is in great condition.",
  },
  {
    id: 2,
    status: "accepted",
    theirItem: {
      id: 102,
      title: "Wool Sweater",
      image: "https://images.unsplash.com/photo-1576566588028-4147f3882f37?w=400&h=500&fit=crop",
      owner: "Emma Wilson",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
    },
    myItem: {
      id: 202,
      title: "Leather Boots",
      image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=500&fit=crop",
    },
    date: "Yesterday",
    message: "This would be perfect for winter!",
  },
  {
    id: 3,
    status: "completed",
    theirItem: {
      id: 103,
      title: "Silk Scarf",
      image: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=400&h=500&fit=crop",
      owner: "Lisa Chen",
      avatar: "https://images.unsplash.com/photo-1544005313-94ddf02805df?w=100&h=100&fit=crop",
    },
    myItem: {
      id: 203,
      title: "Cotton T-Shirt",
      image: "https://images.unsplash.com/photo-1521572163470-46589b1c5a53?w=400&h=500&fit=crop",
    },
    date: "3 days ago",
  },
];

const defaultAvatars = [
  "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&h=200&fit=crop",
  "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop",
  "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop",
  "https://images.unsplash.com/photo-1506794777284-5d8e57341bd5?w=200&h=200&fit=crop",
  "https://images.unsplash.com/photo-1519345182560-3f2917c47205?w=200&h=200&fit=crop",
  "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=200&h=200&fit=crop",
  "https://images.unsplash.com/photo-1531429976967-2b2e67e3e2d5?w=200&h=200&fit=crop",
  "https://images.unsplash.com/photo-1463453083892-3d6d4d6e1b2e?w=200&h=200&fit=crop",
  "https://images.unsplash.com/photo-1544005313-94ddf02805df?w=200&h=200&fit=crop",
  "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop",
  "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&h=200&fit=crop",
  "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&h=200&fit=crop",
];

// Glass Background Component
function GlassBackground() {
  return (
    <div className="fixed inset-0 -z-10 overflow-hidden">
      {/* Base gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900" />
      
      {/* Animated gradient orbs */}
      <motion.div
        className="absolute w-96 h-96 bg-violet-500/30 rounded-full blur-3xl"
        animate={{
          x: [0, 100, 50, 0],
          y: [0, 50, 100, 0],
          scale: [1, 1.2, 0.8, 1],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        style={{ top: "10%", left: "10%" }}
      />
      <motion.div
        className="absolute w-80 h-80 bg-pink-500/30 rounded-full blur-3xl"
        animate={{
          x: [0, -80, -40, 0],
          y: [0, 80, 40, 0],
          scale: [1, 0.9, 1.1, 1],
        }}
        transition={{
          duration: 15,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        style={{ top: "50%", right: "10%" }}
      />
      <motion.div
        className="absolute w-72 h-72 bg-cyan-500/20 rounded-full blur-3xl"
        animate={{
          x: [0, 60, -60, 0],
          y: [0, -60, 60, 0],
          scale: [1, 1.1, 0.9, 1],
        }}
        transition={{
          duration: 18,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        style={{ bottom: "10%", left: "30%" }}
      />
      <motion.div
        className="absolute w-64 h-64 bg-emerald-500/20 rounded-full blur-3xl"
        animate={{
          x: [0, -40, 80, 0],
          y: [0, 80, -40, 0],
          scale: [1, 1.3, 0.7, 1],
        }}
        transition={{
          duration: 22,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        style={{ top: "30%", left: "60%" }}
      />
      
      {/* Glass texture overlay */}
      <div className="absolute inset-0 backdrop-blur-sm" />
      
      {/* Noise texture */}
      <div 
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 400 400' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
        }}
      />
    </div>
  );
}

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [currentView, setCurrentView] = useState<View>("home");
  const [showListingModal, setShowListingModal] = useState(false);
  const [showSwapModal, setShowSwapModal] = useState(false);
  const [showProfilePicModal, setShowProfilePicModal] = useState(false);
  const [selectedItem, setSelectedItem] = useState<ClothingItem | null>(null);
  const [swapRequests, setSwapRequests] = useState<SwapRequest[]>(initialSwapRequests);
  const [listings, setListings] = useState<ClothingItem[]>(clothingItems);
  const [myListings, setMyListings] = useState<ClothingItem[]>(myItems);
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  const handleLogin = (email: string, password: string) => {
    setUser({ 
      name: email.split("@")[0], 
      email,
      avatar: defaultAvatars[Math.floor(Math.random() * defaultAvatars.length)]
    });
    setIsAuthenticated(true);
  };

  const handleSignup = (name: string, email: string, password: string) => {
    setUser({ 
      name, 
      email,
      avatar: defaultAvatars[Math.floor(Math.random() * defaultAvatars.length)]
    });
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setUser(null);
    setCurrentView("home");
  };

  const handleUpdateAvatar = (newAvatar: string) => {
    if (user) {
      setUser({ ...user, avatar: newAvatar });
    }
    setShowProfilePicModal(false);
  };

  const handleRequestSwap = (item: ClothingItem) => {
    setSelectedItem(item);
    setShowSwapModal(true);
  };

  const handleSendSwapRequest = (myItem: ClothingItem, message: string) => {
    if (!selectedItem) return;

    const newRequest: SwapRequest = {
      id: Date.now(),
      status: "pending",
      theirItem: {
        id: selectedItem.id,
        title: selectedItem.title,
        image: selectedItem.image,
        owner: selectedItem.owner.name,
        avatar: selectedItem.owner.avatar,
      },
      myItem: {
        id: myItem.id,
        title: myItem.title,
        image: myItem.image,
      },
      date: "Just now",
      message,
    };

    setSwapRequests([newRequest, ...swapRequests]);
    setShowSwapModal(false);
    setSelectedItem(null);
  };

  const handleAcceptSwap = (requestId: number) => {
    setSwapRequests(
      swapRequests.map((req) =>
        req.id === requestId ? { ...req, status: "accepted" } : req
      )
    );
  };

  const handleDeclineSwap = (requestId: number) => {
    setSwapRequests(
      swapRequests.map((req) =>
        req.id === requestId ? { ...req, status: "declined" } : req
      )
    );
  };

  const handleCompleteSwap = (requestId: number) => {
    setSwapRequests(
      swapRequests.map((req) =>
        req.id === requestId ? { ...req, status: "completed" } : req
      )
    );
  };

  const handleAddListing = (newListing: {
    title: string;
    brand: string;
    category: string;
    size: string;
    condition: string;
    estimatedValue: number;
    image: string;
    location: string;
  }) => {
    const listing: ClothingItem = {
      ...newListing,
      id: Date.now(),
      owner: {
        name: user?.name || "You",
        avatar: user?.avatar || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop",
      },
    };
    setListings([listing, ...listings]);
    setMyListings([listing, ...myListings]);
    setShowListingModal(false);
  };

  // Loading Screen
  if (isLoading) {
    return (
      <div className="min-h-screen relative overflow-hidden">
        <GlassBackground />
        <div className="relative z-10 flex items-center justify-center min-h-screen">
          <motion.div
            className="text-center"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <motion.div
              className="w-24 h-24 bg-white/10 backdrop-blur-xl rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-2xl border border-white/20"
              animate={{
                rotate: [0, 360],
                scale: [1, 1.1, 1],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            >
              <svg className="w-12 h-12 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
              </svg>
            </motion.div>
            <motion.h1
              className="text-4xl font-bold text-white mb-2"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              SwapStyle
            </motion.h1>
            <motion.p
              className="text-white/60"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
            >
              Loading your sustainable fashion journey...
            </motion.p>
            <motion.div
              className="mt-6 flex justify-center gap-2"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
            >
              {[0, 1, 2].map((i) => (
                <motion.div
                  key={i}
                  className="w-3 h-3 bg-white/40 rounded-full"
                  animate={{ 
                    y: [0, -15, 0],
                    opacity: [0.4, 1, 0.4]
                  }}
                  transition={{
                    duration: 0.8,
                    repeat: Infinity,
                    delay: i * 0.15,
                  }}
                />
              ))}
            </motion.div>
          </motion.div>
        </div>
      </div>
    );
  }

  // Auth Screen
  if (!isAuthenticated) {
    return <AuthPage onLogin={handleLogin} onSignup={handleSignup} />;
  }

  return (
    <div className="min-h-screen relative overflow-hidden">
      <GlassBackground />
      
      <motion.div
        className="relative z-10"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <Navbar
          currentView={currentView}
          setCurrentView={setCurrentView}
          onAddListing={() => setShowListingModal(true)}
          user={user}
          onLogout={handleLogout}
        />

        <AnimatePresence mode="wait">
          {currentView === "home" && (
            <motion.div
              key="home"
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 50 }}
              transition={{ duration: 0.3 }}
            >
              <Hero onBrowse={() => setCurrentView("browse")} />
              <motion.div
                className="max-w-7xl mx-auto px-4 sm:px-6 pb-12"
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
              >
                <motion.h2
                  className="text-2xl font-bold text-white mb-6"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                >
                  Featured Items
                </motion.h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
                  {listings.slice(0, 4).map((item, index) => (
                    <ClothingCard
                      key={item.id}
                      item={item}
                      index={index}
                      onRequestSwap={handleRequestSwap}
                    />
                  ))}
                </div>
              </motion.div>
            </motion.div>
          )}

          {currentView === "browse" && (
            <motion.div
              key="browse"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              transition={{ duration: 0.3 }}
              className="max-w-7xl mx-auto px-4 sm:px-6 py-8"
            >
              <motion.div
                className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <h1 className="text-2xl font-bold text-white">Browse Items</h1>
                <div className="flex gap-2">
                  <motion.select
                    className="px-4 py-2 rounded-xl bg-white/10 backdrop-blur-md border border-white/20 text-white text-sm focus:outline-none focus:ring-2 focus:ring-violet-400"
                    whileHover={{ scale: 1.02 }}
                  >
                    <option className="bg-slate-800">All Categories</option>
                    <option className="bg-slate-800">Tops</option>
                    <option className="bg-slate-800">Bottoms</option>
                    <option className="bg-slate-800">Dresses</option>
                    <option className="bg-slate-800">Outerwear</option>
                    <option className="bg-slate-800">Shoes</option>
                    <option className="bg-slate-800">Accessories</option>
                  </motion.select>
                  <motion.select
                    className="px-4 py-2 rounded-xl bg-white/10 backdrop-blur-md border border-white/20 text-white text-sm focus:outline-none focus:ring-2 focus:ring-violet-400"
                    whileHover={{ scale: 1.02 }}
                  >
                    <option className="bg-slate-800">All Sizes</option>
                    <option className="bg-slate-800">XS</option>
                    <option className="bg-slate-800">S</option>
                    <option className="bg-slate-800">M</option>
                    <option className="bg-slate-800">L</option>
                    <option className="bg-slate-800">XL</option>
                  </motion.select>
                </div>
              </motion.div>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
                {listings.map((item, index) => (
                  <ClothingCard
                    key={item.id}
                    item={item}
                    index={index}
                    onRequestSwap={handleRequestSwap}
                  />
                ))}
              </div>
            </motion.div>
          )}

          {currentView === "swaps" && (
            <motion.div
              key="swaps"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.3 }}
            >
              <SwapRequests
                requests={swapRequests}
                onAccept={handleAcceptSwap}
                onDecline={handleDeclineSwap}
                onComplete={handleCompleteSwap}
              />
            </motion.div>
          )}

          {currentView === "profile" && (
            <motion.div
              key="profile"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -30 }}
              transition={{ duration: 0.3 }}
              className="max-w-4xl mx-auto px-4 sm:px-6 py-8"
            >
              <motion.div
                className="bg-white/10 backdrop-blur-xl rounded-3xl border border-white/20 p-6 mb-6 shadow-2xl"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
              >
                <div className="flex items-center gap-4">
                  <motion.div
                    className="relative group cursor-pointer"
                    onClick={() => setShowProfilePicModal(true)}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <motion.img
                      src={user?.avatar}
                      alt="Profile"
                      className="w-24 h-24 rounded-full object-cover border-4 border-white/30 shadow-xl"
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: "spring", stiffness: 200, delay: 0.2 }}
                    />
                    <motion.div
                      className="absolute inset-0 bg-black/50 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                      </svg>
                    </motion.div>
                  </motion.div>
                  <div>
                    <h1 className="text-2xl font-bold text-white">{user?.name}</h1>
                    <p className="text-white/60">{user?.email}</p>
                    <div className="flex items-center gap-4 mt-2">
                      <motion.span
                        className="text-sm text-white/80"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 0.3 }}
                      >
                        <strong className="text-violet-300">{myListings?.length ?? 0}</strong> listings
                      </motion.span>
                      <motion.span
                        className="text-sm text-white/80"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 0.4 }}
                      >
                        <strong className="text-emerald-300">
                          {swapRequests.filter((r) => r.status === "completed").length}
                        </strong>{" "}
                        swaps completed
                      </motion.span>
                    </div>
                  </div>
                </div>
                
                <motion.p
                  className="text-xs text-white/40 mt-4 text-center"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.5 }}
                >
                  Click on your profile picture to change it
                </motion.p>
              </motion.div>

              <motion.h2
                className="text-xl font-bold text-white mb-4"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.2 }}
              >
                My Listings
              </motion.h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {myListings.map((item, index) => (
                  <ClothingCard
                    key={item.id}
                    item={item}
                    index={index}
                    onRequestSwap={handleRequestSwap}
                    isOwnItem
                  />
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {showListingModal && (
            <ListingModal
              onClose={() => setShowListingModal(false)}
              onSubmit={handleAddListing}
            />
          )}
          {showSwapModal && selectedItem && (
            <SwapModal
              item={selectedItem}
              myItems={myListings}
              onClose={() => {
                setShowSwapModal(false);
                setSelectedItem(null);
              }}
              onSend={handleSendSwapRequest}
            />
          )}
          {showProfilePicModal && (
            <ProfilePictureModal
              currentAvatar={user?.avatar || ""}
              avatars={defaultAvatars}
              onClose={() => setShowProfilePicModal(false)}
              onSelect={handleUpdateAvatar}
            />
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}