import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";

interface LoginPageProps {
  onLogin: () => void;
}

export function LoginPage({ onLogin }: LoginPageProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <div className="min-h-screen bg-white flex">
      {/* Left Side - Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-6 sm:p-12">
        <motion.div 
          className="w-full max-w-md"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {/* Logo */}
          <motion.div className="flex items-center gap-3 mb-8" variants={itemVariants}>
            <motion.div 
              className="w-12 h-12 bg-gradient-to-br from-violet-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-purple-200"
              whileHover={{ scale: 1.05, rotate: 5 }}
              whileTap={{ scale: 0.95 }}
            >
              <svg className="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
              </svg>
            </motion.div>
            <span className="text-2xl font-bold bg-gradient-to-r from-violet-600 to-purple-600 bg-clip-text text-transparent">SwapStyle</span>
          </motion.div>
          
          {/* Heading */}
          <motion.h1 className="text-3xl sm:text-4xl font-bold text-slate-800 mb-2" variants={itemVariants}>
            {isLogin ? "Welcome back" : "Join the movement"}
          </motion.h1>
          <motion.p className="text-slate-500 mb-8" variants={itemVariants}>
            {isLogin 
              ? "Sign in to continue swapping sustainably" 
              : "Create an account to start your sustainable fashion journey"}
          </motion.p>
          
          {/* Form */}
          <motion.div className="space-y-4" variants={containerVariants}>
            {!isLogin && (
              <motion.div variants={itemVariants}>
                <Label htmlFor="name">Full Name</Label>
                <Input 
                  id="name" 
                  type="text"
                  placeholder="John Doe"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="mt-1.5 h-12 border-violet-200 focus:border-violet-500 focus:ring-violet-500"
                />
              </motion.div>
            )}
            
            <motion.div variants={itemVariants}>
              <Label htmlFor="email">Email</Label>
              <Input 
                id="email" 
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="mt-1.5 h-12 border-violet-200 focus:border-violet-500 focus:ring-violet-500"
              />
            </motion.div>
            
            <motion.div variants={itemVariants}>
              <div className="flex items-center justify-between mb-1.5">
                <Label htmlFor="password">Password</Label>
                {isLogin && (
                  <motion.button 
                    className="text-sm text-violet-600 hover:text-violet-700"
                    whileHover={{ x: 2 }}
                  >
                    Forgot password?
                  </motion.button>
                )}
              </div>
              <Input 
                id="password" 
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="h-12 border-violet-200 focus:border-violet-500 focus:ring-violet-500"
              />
            </motion.div>
            
            {!isLogin && (
              <motion.div className="flex items-center gap-2" variants={itemVariants}>
                <input type="checkbox" id="terms" className="w-4 h-4 rounded border-violet-300 text-violet-600" />
                <Label htmlFor="terms" className="text-sm text-slate-600">
                  I agree to the <a href="#" className="text-violet-600 hover:underline">Terms</a> and <a href="#" className="text-violet-600 hover:underline">Privacy Policy</a>
                </Label>
              </motion.div>
            )}
            
            <motion.div variants={itemVariants}>
              <Button 
                onClick={onLogin}
                className="w-full h-12 bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 text-base shadow-lg shadow-purple-200"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                {isLogin ? "Sign In" : "Create Account"}
              </Button>
            </motion.div>
          </motion.div>
          
          {/* Divider */}
          <motion.div className="flex items-center gap-4 my-6" variants={itemVariants}>
            <div className="flex-1 h-px bg-gradient-to-r from-transparent via-violet-200 to-transparent"></div>
            <span className="text-sm text-slate-400">or continue with</span>
            <div className="flex-1 h-px bg-gradient-to-r from-transparent via-violet-200 to-transparent"></div>
          </motion.div>
          
          {/* Social Login */}
          <motion.div className="grid grid-cols-2 gap-4" variants={itemVariants}>
            <motion.button 
              className="flex items-center justify-center gap-2 h-12 border border-violet-200 rounded-xl hover:bg-violet-50 transition-colors"
              whileHover={{ scale: 1.02, borderColor: "#8b5cf6" }}
              whileTap={{ scale: 0.98 }}
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h6.01c-.27 1.02-1.01 1.85-2.16 2.39v3.96h3.49c2.04-1.87 3.22-4.62 3.22-8.36z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.49-3.96c-.97.66-2.21 1.06-3.79 1.06-2.92 0-5.39-1.98-6.28-4.64H2.22v4.09C4.03 20.98 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.72 14.8c-.23-.66-.36-1.36-.36-2.08s.13-1.42.36-2.08V6.55H2.22C1.44 8.1 1 9.99 1 12.02s.44 3.92 1.22 5.47l3.5-2.69z"/>
                <path fill="#EA4335" d="M12 5.02c1.64 0 3.1.56 4.26 1.66l3.2-3.2C17.45 1.78 14.97 1 12 1 7.7 1 4.03 3.02 2.22 6.55l3.5 2.69c.89-2.66 3.36-4.64 6.28-4.64z"/>
              </svg>
              <span className="text-sm font-medium text-slate-700">Google</span>
            </motion.button>
            <motion.button 
              className="flex items-center justify-center gap-2 h-12 border border-violet-200 rounded-xl hover:bg-violet-50 transition-colors"
              whileHover={{ scale: 1.02, borderColor: "#8b5cf6" }}
              whileTap={{ scale: 0.98 }}
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2C6.477 2 2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.879V14.89h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.989C18.343 21.129 22 16.99 22 12c0-5.523-4.477-10-10-10z"/>
              </svg>
              <span className="text-sm font-medium text-slate-700">Facebook</span>
            </motion.button>
          </motion.div>
          
          {/* Toggle */}
          <motion.p className="text-center text-slate-600 mt-8" variants={itemVariants}>
            {isLogin ? "Don't have an account?" : "Already have an account?"}{" "}
            <motion.button 
              onClick={() => setIsLogin(!isLogin)}
              className="text-violet-600 font-medium hover:text-violet-700"
              whileHover={{ scale: 1.05 }}
            >
              {isLogin ? "Sign up" : "Sign in"}
            </motion.button>
          </motion.p>
        </motion.div>
      </div>
      
      {/* Right Side - Image */}
      <motion.div 
        className="hidden lg:block lg:w-1/2 relative"
        initial={{ opacity: 0, x: 50 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.8, delay: 0.3 }}
      >
        <motion.img 
          src="https://images.unsplash.com/photo-1489987707025-afc3f4b73f66?w=800&h=900&fit=crop"
          alt="Sustainable Fashion"
          className="w-full h-full object-cover"
          initial={{ scale: 1.1 }}
          animate={{ scale: 1 }}
          transition={{ duration: 1.2 }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-purple-900/60 via-purple-600/30 to-violet-400/20"></div>
        
        <motion.div 
          className="absolute bottom-0 left-0 right-0 p-12 text-white"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          <motion.h2 
            className="text-3xl font-bold mb-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
          >
            Swap, Don't Shop
          </motion.h2>
          <motion.p 
            className="text-lg text-white/80 mb-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.9 }}
          >
            Join thousands of fashion lovers exchanging clothes sustainably. 
            Reduce waste, refresh your wardrobe, and connect with your community.
          </motion.p>
          <motion.div 
            className="flex items-center gap-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
          >
            {[
              { value: "12K+", label: "Active Swappers" },
              { value: "45K+", label: "Items Listed" },
              { value: "8K+", label: "Successful Swaps" }
            ].map((stat, index) => (
              <motion.div 
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1 + index * 0.1 }}
              >
                <p className="text-2xl font-bold">{stat.value}</p>
                <p className="text-sm text-white/70">{stat.label}</p>
              </motion.div>
            ))}
          </motion.div>
        </motion.div>
      </motion.div>
    </div>
  );
}