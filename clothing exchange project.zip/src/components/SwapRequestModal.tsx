import { useState } from "react";
import { Button } from "./ui/button";
import { listings } from "../utils/data";

interface SwapRequestModalProps {
  listingId: number;
  onClose: () => void;
}

export function SwapRequestModal({ listingId, onClose }: SwapRequestModalProps) {
  const [step, setStep] = useState(1);
  const [message, setMessage] = useState("");
  
  const listing = listings.find(l => l.id === listingId);
  
  // Mock user's items
  const myItems = [
    { id: 1, title: "Vintage Band Tee", value: 30, image: "https://images.unsplash.com/photo-1576566588028-4147f3882f37?w=200&h=200&fit=crop" },
    { id: 2, title: "Wool Sweater", value: 25, image: "https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=200&h=200&fit=crop" },
    { id: 3, title: "Canvas Sneakers", value: 30, image: "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=200&h=200&fit=crop" },
    { id: 4, title: "Silk Blouse", value: 40, image: "https://images.unsplash.com/photo-1596755094514-f87e34085b5c?w=200&h=200&fit=crop" },
  ];
  
  const [selectedItem, setSelectedItem] = useState<number | null>(null);
  
  if (!listing) return null;

  const placeholderImage = "https://images.unsplash.com/photo-1542272604-787c3835535d?w=400&h=400&fit=crop";

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-slate-200">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-slate-800">Request Swap</h2>
            <button onClick={onClose} className="w-10 h-10 rounded-full hover:bg-slate-100 flex items-center justify-center">
              <svg className="w-5 h-5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>
        
        <div className="p-6">
          {/* Target Item */}
          <div className="bg-emerald-50 rounded-xl p-4 mb-6">
            <p className="text-xs text-emerald-600 mb-2">You want to swap for:</p>
            <div className="flex items-center gap-4">
              <img 
                src={placeholderImage}
                alt={listing.title}
                className="w-16 h-16 object-cover rounded-lg"
              />
              <div className="flex-1">
                <h3 className="font-semibold text-slate-800">{listing.title}</h3>
                <p className="text-sm text-slate-500">{listing.brand} • Size {listing.size}</p>
              </div>
              <div className="text-right">
                <p className="text-xs text-slate-500">Value</p>
                <p className="text-lg font-bold text-emerald-600">${listing.value}</p>
              </div>
            </div>
          </div>
          
          {step === 1 && (
            <div>
              <h3 className="font-semibold text-slate-800 mb-4">Select an item to offer:</h3>
              <div className="grid grid-cols-2 gap-4 mb-6">
                {myItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setSelectedItem(item.id)}
                    className={`p-4 rounded-xl border-2 transition-all text-left ${
                      selectedItem === item.id 
                        ? "border-emerald-500 bg-emerald-50" 
                        : "border-slate-200 hover:border-slate-300"
                    }`}
                  >
                    <img 
                      src={item.image}
                      alt={item.title}
                      className="w-full h-24 object-cover rounded-lg mb-2"
                    />
                    <h4 className="font-medium text-slate-800">{item.title}</h4>
                    <p className="text-sm text-emerald-600 font-medium">${item.value}</p>
                  </button>
                ))}
              </div>
              
              <div className="flex gap-3">
                <Button variant="outline" onClick={onClose} className="flex-1">
                  Cancel
                </Button>
                <Button 
                  onClick={() => selectedItem && setStep(2)}
                  disabled={!selectedItem}
                  className="flex-1 bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50"
                >
                  Continue
                </Button>
              </div>
            </div>
          )}
          
          {step === 2 && (
            <div>
              {/* Value Comparison */}
              <div className="bg-slate-100 rounded-xl p-4 mb-6">
                <div className="flex items-center justify-between">
                  <div className="text-center">
                    <p className="text-sm text-slate-500">Your Item</p>
                    <p className="text-xl font-bold text-slate-800">$30</p>
                  </div>
                  
                  <div className="flex-1 flex items-center justify-center px-4">
                    <div className="flex items-center gap-2">
                      <div className="w-20 h-1 bg-slate-300 rounded"></div>
                      <svg className="w-5 h-5 text-emerald-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
                      </svg>
                      <div className="w-20 h-1 bg-slate-300 rounded"></div>
                    </div>
                  </div>
                  
                  <div className="text-center">
                    <p className="text-sm text-slate-500">Their Item</p>
                    <p className="text-xl font-bold text-slate-800">${listing.value}</p>
                  </div>
                </div>
                
                <div className="mt-3 pt-3 border-t border-slate-200 text-center">
                  <span className="bg-amber-100 text-amber-700 text-sm font-medium px-3 py-1 rounded-full">
                    Value difference: ${Math.abs(listing.value - 30)}
                  </span>
                </div>
              </div>
              
              {/* Message */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Add a message (optional)
                </label>
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Introduce yourself and explain why you'd like to swap..."
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 resize-none"
                  rows={3}
                />
              </div>
              
              {/* Tips */}
              <div className="bg-blue-50 rounded-xl p-4 mb-6">
                <div className="flex items-start gap-3">
                  <svg className="w-5 h-5 text-blue-500 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <div>
                    <p className="text-sm font-medium text-blue-800">Swap Tips</p>
                    <p className="text-xs text-blue-600 mt-1">
                      Be friendly and responsive. Mention if you're flexible on meetup times or locations.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="flex gap-3">
                <Button variant="outline" onClick={() => setStep(1)} className="flex-1">
                  Back
                </Button>
                <Button 
                  onClick={() => {
                    alert("Swap request sent!");
                    onClose();
                  }}
                  className="flex-1 bg-emerald-500 hover:bg-emerald-600"
                >
                  Send Request
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}