import { useState } from "react";
import { Button } from "./ui/button";
import { swapRequests } from "../utils/data";

interface SwapResponseModalProps {
  swapId: number;
  onClose: () => void;
  onOpenChat: (id: number) => void;
}

export function SwapResponseModal({ swapId, onClose, onOpenChat }: SwapResponseModalProps) {
  const [selectedAction, setSelectedAction] = useState<"accept" | "decline" | "counter" | null>(null);
  const [counterValue, setCounterValue] = useState("");
  
  const request = swapRequests.find(r => r.id === swapId);
  
  if (!request) return null;

  const itemImages = [
    "https://images.unsplash.com/photo-1576566588028-4147f3882f37?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400&h=400&fit=crop",
  ];

  const handleAccept = () => {
    setSelectedAction("accept");
  };

  const handleDecline = () => {
    setSelectedAction("decline");
  };

  const handleCounter = () => {
    setSelectedAction("counter");
  };

  const handleConfirm = () => {
    // In a real app, this would send the response to the backend
    alert(selectedAction === "accept" ? "Swap accepted!" : selectedAction === "decline" ? "Swap declined" : "Counter offer sent!");
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-slate-200">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-slate-800">Swap Request Details</h2>
            <button onClick={onClose} className="w-10 h-10 rounded-full hover:bg-slate-100 flex items-center justify-center">
              <svg className="w-5 h-5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>
        
        <div className="p-6">
          {/* User Info */}
          <div className="flex items-center gap-3 mb-6 pb-4 border-b border-slate-100">
            <img 
              src={`https://ui-avatars.com/api/?name=${request.user}&background=c4b5fd&color=5b21b6&bold=true`}
              alt={request.user}
              className="w-12 h-12 rounded-full"
            />
            <div>
              <h3 className="font-semibold text-slate-800">{request.user}</h3>
              <p className="text-sm text-slate-500">Sent {request.time}</p>
            </div>
            <span className={`ml-auto px-3 py-1 rounded-full text-sm font-medium ${
              request.status === "pending" ? "bg-amber-100 text-amber-700" : 
              request.status === "accepted" ? "bg-emerald-100 text-emerald-700" : 
              "bg-blue-100 text-blue-700"
            }`}>
              {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
            </span>
          </div>
          
          {/* Items Comparison */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-slate-50 rounded-xl p-4">
              <p className="text-xs text-slate-500 mb-2 text-center">Their Item</p>
              <img 
                src={itemImages[0]} 
                alt={request.theirItem}
                className="w-full h-32 object-cover rounded-lg mb-3"
              />
              <h4 className="font-semibold text-slate-800 text-center">{request.theirItem}</h4>
            </div>
            
            <div className="bg-emerald-50 rounded-xl p-4">
              <p className="text-xs text-emerald-600 mb-2 text-center">Your Item</p>
              <img 
                src={itemImages[1]} 
                alt={request.myItem}
                className="w-full h-32 object-cover rounded-lg mb-3"
              />
              <h4 className="font-semibold text-slate-800 text-center">{request.myItem}</h4>
            </div>
          </div>
          
          {/* Value Comparison */}
          <div className="bg-slate-100 rounded-xl p-4 mb-6">
            <div className="flex items-center justify-between">
              <div className="text-center">
                <p className="text-sm text-slate-500">Their Value</p>
                <p className="text-xl font-bold text-slate-800">$45</p>
              </div>
              
              <div className="flex-1 flex items-center justify-center">
                <div className={`px-4 py-2 rounded-full text-sm font-medium ${
                  request.valueDiff > 0 ? "bg-emerald-100 text-emerald-700" : 
                  request.valueDiff < 0 ? "bg-rose-100 text-rose-700" : 
                  "bg-slate-200 text-slate-700"
                }`}>
                  {request.valueDiff > 0 ? "You gain $" : request.valueDiff < 0 ? "You lose $" : "Even swap"}
                  {request.valueDiff !== 0 && Math.abs(request.valueDiff)}
                </div>
              </div>
              
              <div className="text-center">
                <p className="text-sm text-slate-500">Your Value</p>
                <p className="text-xl font-bold text-slate-800">$40</p>
              </div>
            </div>
          </div>
          
          {/* Action Buttons */}
          {selectedAction === null ? (
            <div className="space-y-3">
              <Button 
                onClick={handleAccept}
                className="w-full bg-emerald-500 hover:bg-emerald-600 py-3"
              >
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                Accept Swap
              </Button>
              
              <Button 
                onClick={handleCounter}
                variant="outline"
                className="w-full py-3 border-slate-200"
              >
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
                </svg>
                Send Counter Offer
              </Button>
              
              <Button 
                onClick={handleDecline}
                variant="outline"
                className="w-full py-3 text-rose-500 border-rose-200 hover:bg-rose-50"
              >
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
                Decline
              </Button>
            </div>
          ) : selectedAction === "counter" ? (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  What would you like to propose?
                </label>
                <textarea
                  value={counterValue}
                  onChange={(e) => setCounterValue(e.target.value)}
                  placeholder="e.g., Could you add another item to make the values even? Or I could add a scarf to my offer..."
                  className="w-full px-4 py-3 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 resize-none"
                  rows={4}
                />
              </div>
              
              <div className="flex gap-3">
                <Button 
                  variant="outline"
                  onClick={() => setSelectedAction(null)}
                  className="flex-1"
                >
                  Back
                </Button>
                <Button 
                  onClick={handleConfirm}
                  className="flex-1 bg-emerald-500 hover:bg-emerald-600"
                >
                  Send Counter
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className={`p-4 rounded-xl text-center ${
                selectedAction === "accept" ? "bg-emerald-50" : "bg-rose-50"
              }`}>
                <div className={`w-12 h-12 rounded-full mx-auto mb-3 flex items-center justify-center ${
                  selectedAction === "accept" ? "bg-emerald-100" : "bg-rose-100"
                }`}>
                  {selectedAction === "accept" ? (
                    <svg className="w-6 h-6 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  ) : (
                    <svg className="w-6 h-6 text-rose-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  )}
                </div>
                <p className={`font-medium ${
                  selectedAction === "accept" ? "text-emerald-700" : "text-rose-700"
                }`}>
                  {selectedAction === "accept" 
                    ? "You're about to accept this swap request" 
                    : "You're about to decline this swap request"}
                </p>
              </div>
              
              <div className="flex gap-3">
                <Button 
                  variant="outline"
                  onClick={() => setSelectedAction(null)}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button 
                  onClick={handleConfirm}
                  className={`flex-1 ${
                    selectedAction === "accept" 
                      ? "bg-emerald-500 hover:bg-emerald-600" 
                      : "bg-rose-500 hover:bg-rose-600"
                  }`}
                >
                  Confirm
                </Button>
              </div>
            </div>
          )}
          
          {/* Quick Actions */}
          <div className="mt-6 pt-4 border-t border-slate-100">
            <Button 
              onClick={() => {
                onClose();
                onOpenChat(swapId);
              }}
              variant="outline"
              className="w-full border-slate-200"
            >
              <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
              </svg>
              Open Chat with {request.user}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}