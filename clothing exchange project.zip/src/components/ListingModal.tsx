import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";

interface ListingModalProps {
  onClose: () => void;
}

export function ListingModal({ onClose }: ListingModalProps) {
  const [step, setStep] = useState(1);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedSize, setSelectedSize] = useState<string | null>(null);
  const [selectedCondition, setSelectedCondition] = useState<string | null>(null);
  
  const categories = ["Tops", "Bottoms", "Dresses", "Outerwear", "Shoes", "Accessories"];
  const conditions = ["New with Tags", "Like New", "Good", "Fair"];
  const sizes = ["XS", "S", "M", "L", "XL", "XXL", "One Size"];

  const modalVariants = {
    hidden: { opacity: 0, scale: 0.9 },
    visible: { opacity: 1, scale: 1 }
  };

  return (
    <motion.div 
      className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <motion.div 
        className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
        variants={modalVariants}
        initial="hidden"
        animate="visible"
        exit="hidden"
      >
        <div className="p-6 border-b border-violet-100">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-slate-800">Create New Listing</h2>
            <motion.button 
              onClick={onClose} 
              className="w-10 h-10 rounded-full hover:bg-violet-50 flex items-center justify-center"
              whileHover={{ scale: 1.1, rotate: 90 }}
              whileTap={{ scale: 0.9 }}
            >
              <svg className="w-5 h-5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </motion.button>
          </div>
          
          <div className="flex items-center gap-2 mt-4">
            {[1, 2, 3].map((s) => (
              <motion.div 
                key={s}
                className={`flex-1 h-1.5 rounded-full ${step >= s ? "bg-gradient-to-r from-violet-500 to-purple-600" : "bg-slate-200"}`}
                initial={{ scaleX: 0 }}
                animate={{ scaleX: 1 }}
                transition={{ delay: s * 0.1 }}
              />
            ))}
          </div>
          
          <div className="flex items-center justify-between mt-2">
            {["Photos", "Details", "Value"].map((label, index) => (
              <span key={label} className={`text-xs ${step >= index + 1 ? "text-violet-600 font-medium" : "text-slate-400"}`}>
                {label}
              </span>
            ))}
          </div>
        </div>
        
        <div className="p-6">
          <AnimatePresence mode="wait">
            {step === 1 && (
              <motion.div 
                key="step1"
                className="space-y-6"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
              >
                <div>
                  <Label className="mb-2 block">Photos</Label>
                  <div className="grid grid-cols-4 gap-3">
                    <motion.div 
                      className="aspect-square bg-gradient-to-br from-violet-50 to-purple-50 border-2 border-dashed border-violet-300 rounded-xl flex flex-col items-center justify-center cursor-pointer hover:bg-violet-100 transition-colors"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <motion.svg 
                        className="w-8 h-8 text-violet-400" 
                        fill="none" 
                        stroke="currentColor" 
                        viewBox="0 0 24 24"
                        animate={{ rotate: [0, 90, 0] }}
                        transition={{ duration: 2, repeat: Infinity }}
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                      </motion.svg>
                      <span className="text-xs text-violet-500 mt-1">Add</span>
                    </motion.div>
                    {[1, 2, 3].map((i) => (
                      <motion.div 
                        key={i} 
                        className="aspect-square bg-slate-100 border-2 border-dashed border-slate-200 rounded-xl"
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: i * 0.1 }}
                      />
                    ))}
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="title">Title</Label>
                  <Input id="title" placeholder="e.g., Vintage Levi's Denim Jacket" className="mt-1.5 h-12 border-violet-200 focus:border-violet-500 focus:ring-violet-500" />
                </div>
                
                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea id="description" placeholder="Describe your item's condition, fit, and any notable details..." className="mt-1.5 border-violet-200 focus:border-violet-500 focus:ring-violet-500" rows={3} />
                </div>
              </motion.div>
            )}
            
            {step === 2 && (
              <motion.div 
                key="step2"
                className="space-y-6"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
              >
                <div>
                  <Label className="mb-2 block">Category</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {categories.map((cat, index) => (
                      <motion.button 
                        key={cat} 
                        className={`px-4 py-2.5 rounded-lg text-sm font-medium transition-all ${
                          selectedCategory === cat 
                            ? 'bg-gradient-to-r from-violet-500 to-purple-600 text-white shadow-lg shadow-purple-200' 
                            : 'border border-violet-200 text-slate-600 hover:bg-violet-50'
                        }`}
                        onClick={() => setSelectedCategory(cat)}
                        whileHover={{ scale: 1.03 }}
                        whileTap={{ scale: 0.97 }}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.05 }}
                      >
                        {cat}
                      </motion.button>
                    ))}
                  </div>
                </div>
                
                <div>
                  <Label className="mb-2 block">Size</Label>
                  <div className="flex flex-wrap gap-2">
                    {sizes.map((size, index) => (
                      <motion.button 
                        key={size} 
                        className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                          selectedSize === size 
                            ? 'bg-gradient-to-r from-violet-500 to-purple-600 text-white shadow-lg shadow-purple-200' 
                            : 'border border-violet-200 text-slate-600 hover:bg-violet-50'
                        }`}
                        onClick={() => setSelectedSize(size)}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: index * 0.03 }}
                      >
                        {size}
                      </motion.button>
                    ))}
                  </div>
                </div>
                
                <div>
                  <Label className="mb-2 block">Condition</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {conditions.map((condition, index) => (
                      <motion.button 
                        key={condition} 
                        className={`px-4 py-2.5 rounded-lg text-sm font-medium transition-all ${
                          selectedCondition === condition 
                            ? 'bg-gradient-to-r from-violet-500 to-purple-600 text-white shadow-lg shadow-purple-200' 
                            : 'border border-violet-200 text-slate-600 hover:bg-violet-50'
                        }`}
                        onClick={() => setSelectedCondition(condition)}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.05 }}
                      >
                        {condition}
                      </motion.button>
                    ))}
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="brand">Brand</Label>
                  <Input id="brand" placeholder="e.g., Levi's, Zara, H&M" className="mt-1.5 h-12 border-violet-200 focus:border-violet-500 focus:ring-violet-500" />
                </div>
              </motion.div>
            )}
            
            {step === 3 && (
              <motion.div 
                key="step3"
                className="space-y-6"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
              >
                <motion.div 
                  className="bg-gradient-to-br from-violet-50 to-purple-50 rounded-xl p-6 text-center border border-violet-100"
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 0.2 }}
                >
                  <motion.div 
                    className="w-16 h-16 bg-gradient-to-br from-violet-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg shadow-purple-200"
                    animate={{ scale: [1, 1.1, 1] }}
                    transition={{ duration: 2, repeat: Infinity }}
                  >
                    <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                    </svg>
                  </motion.div>
                  <h3 className="text-lg font-semibold text-slate-800 mb-2">Estimated Swap Value</h3>
                  <motion.p 
                    className="text-4xl font-bold bg-gradient-to-r from-violet-600 to-purple-600 bg-clip-text text-transparent"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.4, type: "spring" }}
                  >
                    $35
                  </motion.p>
                  <p className="text-sm text-slate-500 mt-2">Based on brand, condition, and market data</p>
                </motion.div>
                
                <div>
                  <Label htmlFor="location">Pickup Location</Label>
                  <Input id="location" placeholder="Enter your location" className="mt-1.5 h-12 border-violet-200 focus:border-violet-500 focus:ring-violet-500" />
                </div>
                
                <div className="flex items-center gap-2">
                  <input type="checkbox" id="shipping" className="w-4 h-4 rounded border-violet-300 text-violet-600" />
                  <Label htmlFor="shipping" className="text-sm text-slate-600">
                    I'm open to shipping for remote swaps
                  </Label>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        
        <div className="p-6 border-t border-violet-100 flex items-center justify-between gap-4 bg-slate-50">
          {step > 1 && (
            <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              <Button 
                variant="outline" 
                onClick={() => setStep(step - 1)}
                className="border-violet-200 text-violet-700 hover:bg-violet-50"
              >
                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
                Back
              </Button>
            </motion.div>
          )}
          
          <div className="flex-1"></div>
          
          {step < 3 ? (
            <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              <Button 
                onClick={() => setStep(step + 1)}
                className="bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 shadow-lg shadow-purple-200"
              >
                Continue
                <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </Button>
            </motion.div>
          ) : (
            <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              <Button 
                onClick={onClose}
                className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 shadow-lg shadow-emerald-200"
              >
                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                Publish Listing
              </Button>
            </motion.div>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}