import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

interface Notification {
  id: number;
  type: "swap_request" | "message" | "swap_accepted" | "swap_declined" | "listing_liked";
  title: string;
  description: string;
  time: string;
  read: boolean;
  avatar?: string;
  image?: string;
}

interface NotificationDropdownProps {
  isOpen: boolean;
  onClose: () => void;
}

export function NotificationDropdown({ isOpen, onClose }: NotificationDropdownProps) {
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: 1,
      type: "swap_request",
      title: "New Swap Request",
      description: "Sarah wants to swap her Vintage Dress for your Denim Jacket",
      time: "2 min ago",
      read: false,
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
    },
    {
      id: 2,
      type: "message",
      title: "New Message",
      description: "Mike sent you a message about the Leather Boots",
      time: "15 min ago",
      read: false,
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
    },
    {
      id: 3,
      type: "swap_accepted",
      title: "Swap Accepted!",
      description: "Emma accepted your swap request for the Summer Top",
      time: "1 hour ago",
      read: true,
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
    },
    {
      id: 4,
      type: "listing_liked",
      title: "Listing Liked",
      description: "12 people liked your Vintage Denim Jacket listing",
      time: "3 hours ago",
      read: true,
      image: "https://images.unsplash.com/photo-1576566588028-4147f3882f37?w=100&h=100&fit=crop",
    },
    {
      id: 5,
      type: "swap_declined",
      title: "Swap Declined",
      description: "John declined your swap request for the Sneakers",
      time: "Yesterday",
      read: true,
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop",
    },
    {
      id: 6,
      type: "swap_request",
      title: "New Swap Request",
      description: "Lisa wants to swap her Wool Sweater for your Summer Dress",
      time: "Yesterday",
      read: true,
      avatar: "https://images.unsplash.com/photo-1544005313-94ddf02805df?w=100&h=100&fit=crop",
    },
  ]);

  const [filter, setFilter] = useState<"all" | "unread">("all");

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "swap_request":
        return (
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center shadow-lg shadow-purple-200">
            <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
            </svg>
          </div>
        );
      case "message":
        return (
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center shadow-lg shadow-blue-200">
            <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
            </svg>
          </div>
        );
      case "swap_accepted":
        return (
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center shadow-lg shadow-emerald-200">
            <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
        );
      case "swap_declined":
        return (
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-rose-500 to-pink-500 flex items-center justify-center shadow-lg shadow-rose-200">
            <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </div>
        );
      case "listing_liked":
        return (
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center shadow-lg shadow-amber-200">
            <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
            </svg>
          </div>
        );
      default:
        return null;
    }
  };

  const markAsRead = (id: number) => {
    setNotifications(
      notifications.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const markAllAsRead = () => {
    setNotifications(notifications.map((n) => ({ ...n, read: true })));
  };

  const deleteNotification = (id: number) => {
    setNotifications(notifications.filter((n) => n.id !== id));
  };

  const filteredNotifications = filter === "all" 
    ? notifications 
    : notifications.filter((n) => !n.read);

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            className="fixed inset-0 z-40"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />

          {/* Dropdown Panel */}
          <motion.div
            className="fixed right-4 top-16 w-full max-w-md bg-white rounded-2xl shadow-2xl border border-violet-100 z-50 overflow-hidden"
            initial={{ opacity: 0, y: -10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.95 }}
            transition={{ duration: 0.2 }}
          >
            {/* Header */}
            <div className="p-4 border-b border-violet-100 bg-gradient-to-r from-violet-50 to-purple-50">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <h3 className="text-lg font-bold text-slate-800">Notifications</h3>
                  {unreadCount > 0 && (
                    <motion.span
                      className="px-2 py-0.5 text-xs font-bold bg-gradient-to-r from-violet-500 to-purple-600 text-white rounded-full"
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: "spring" }}
                    >
                      {unreadCount}
                    </motion.span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <motion.button
                    onClick={() => setFilter(filter === "all" ? "unread" : "all")}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
                      filter === "unread"
                        ? "bg-violet-100 text-violet-700"
                        : "text-slate-500 hover:bg-slate-100"
                    }`}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    {filter === "all" ? "Unread Only" : "All"}
                  </motion.button>
                  {unreadCount > 0 && (
                    <motion.button
                      onClick={markAllAsRead}
                      className="px-3 py-1.5 text-xs font-medium text-violet-600 hover:bg-violet-100 rounded-lg transition-all"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      Mark all read
                    </motion.button>
                  )}
                </div>
              </div>
            </div>

            {/* Notifications List */}
            <div className="max-h-96 overflow-y-auto">
              {filteredNotifications.length === 0 ? (
                <motion.div
                  className="p-8 text-center"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                >
                  <motion.div
                    className="w-16 h-16 bg-gradient-to-br from-violet-100 to-purple-100 rounded-full flex items-center justify-center mx-auto mb-4"
                    animate={{ scale: [1, 1.1, 1] }}
                    transition={{ duration: 2, repeat: Infinity }}
                  >
                    <svg className="w-8 h-8 text-violet-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                    </svg>
                  </motion.div>
                  <p className="text-slate-500 text-sm">
                    {filter === "unread" ? "No unread notifications" : "No notifications yet"}
                  </p>
                </motion.div>
              ) : (
                <div className="divide-y divide-violet-50">
                  {filteredNotifications.map((notification, index) => (
                    <motion.div
                      key={notification.id}
                      className={`relative p-4 hover:bg-violet-50 transition-colors cursor-pointer group ${
                        !notification.read ? "bg-gradient-to-r from-violet-50/50 to-purple-50/50" : ""
                      }`}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05 }}
                      onClick={() => markAsRead(notification.id)}
                    >
                      <div className="flex items-start gap-3">
                        {/* Avatar or Icon */}
                        <div className="relative flex-shrink-0">
                          {notification.avatar ? (
                            <img
                              src={notification.avatar}
                              alt=""
                              className="w-10 h-10 rounded-full object-cover ring-2 ring-white shadow-md"
                            />
                          ) : notification.image ? (
                            <img
                              src={notification.image}
                              alt=""
                              className="w-10 h-10 rounded-lg object-cover ring-2 ring-white shadow-md"
                            />
                          ) : (
                            getNotificationIcon(notification.type)
                          )}
                          {!notification.read && (
                            <motion.div
                              className="absolute -top-0.5 -right-0.5 w-3 h-3 bg-gradient-to-r from-violet-500 to-purple-600 rounded-full border-2 border-white"
                              animate={{ scale: [1, 1.2, 1] }}
                              transition={{ duration: 1.5, repeat: Infinity }}
                            />
                          )}
                        </div>

                        {/* Content */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <h4 className="text-sm font-semibold text-slate-800 truncate">
                              {notification.title}
                            </h4>
                            <span className="text-xs text-slate-400 flex-shrink-0">
                              {notification.time}
                            </span>
                          </div>
                          <p className="text-sm text-slate-500 mt-0.5 line-clamp-2">
                            {notification.description}
                          </p>

                          {/* Action Buttons */}
                          <div className="flex items-center gap-2 mt-2">
                            {notification.type === "swap_request" && (
                              <>
                                <motion.button
                                  className="px-3 py-1 text-xs font-medium bg-gradient-to-r from-emerald-500 to-teal-500 text-white rounded-lg shadow-md"
                                  whileHover={{ scale: 1.05 }}
                                  whileTap={{ scale: 0.95 }}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    markAsRead(notification.id);
                                  }}
                                >
                                  Accept
                                </motion.button>
                                <motion.button
                                  className="px-3 py-1 text-xs font-medium border border-rose-200 text-rose-600 rounded-lg hover:bg-rose-50"
                                  whileHover={{ scale: 1.05 }}
                                  whileTap={{ scale: 0.95 }}
                                  onClick={(e) => e.stopPropagation()}
                                >
                                  Decline
                                </motion.button>
                              </>
                            )}
                            {notification.type === "message" && (
                              <motion.button
                                className="px-3 py-1 text-xs font-medium bg-gradient-to-r from-violet-500 to-purple-600 text-white rounded-lg shadow-md"
                                whileHover={{ scale: 1.05 }}
                                whileTap={{ scale: 0.95 }}
                                onClick={(e) => e.stopPropagation()}
                              >
                                Reply
                              </motion.button>
                            )}
                            {notification.type === "swap_accepted" && (
                              <motion.button
                                className="px-3 py-1 text-xs font-medium bg-gradient-to-r from-blue-500 to-cyan-500 text-white rounded-lg shadow-md"
                                whileHover={{ scale: 1.05 }}
                                whileTap={{ scale: 0.95 }}
                                onClick={(e) => e.stopPropagation()}
                              >
                                View Details
                              </motion.button>
                            )}
                          </div>
                        </div>

                        {/* Delete Button */}
                        <motion.button
                          className="opacity-0 group-hover:opacity-100 p-1.5 rounded-full hover:bg-rose-100 text-slate-400 hover:text-rose-500 transition-all"
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          onClick={(e) => {
                            e.stopPropagation();
                            deleteNotification(notification.id);
                          }}
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                          </svg>
                        </motion.button>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer */}
            {filteredNotifications.length > 0 && (
              <div className="p-3 border-t border-violet-100 bg-gradient-to-r from-violet-50 to-purple-50">
                <motion.button
                  className="w-full py-2 text-sm font-medium text-violet-600 hover:bg-violet-100 rounded-lg transition-all"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  View All Notifications
                </motion.button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}