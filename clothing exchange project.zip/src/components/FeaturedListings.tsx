import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "./ui/button";
import { listings } from "../utils/data";
import { SwapRequestModal } from "./SwapRequestModal";

export function FeaturedListings() {
  const [filter, setFilter] = useState("all");
  const [selectedListing, setSelectedListing] = useState<number | null>(null);
  
  const placeholderImages = [
    "https://images.unsplash.com/photo-1542272604-787c3835535d?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1541099649105-69a8b5b6a8e7?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1548036328-c9fa89f128fa?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1596755094514-f87e34085b5c?w=400&h=400&fit=crop",
    "https://images.unsplash.com/photo-1583496661160-fb58863a2aa5?w=400&h=400&fit=crop",
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0 }
  };
  
  return (
    <motion.section 
      className="py-8 sm:py-12"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <motion.div 
          className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6 sm:mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-800">Featured Items</h2>
            <p className="text-slate-500 mt-1 text-sm sm:text-base">Discover unique pieces ready for swap</p>
          </div>
          
          <motion.select 
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="flex-1 sm:flex-none bg-white border border-violet-200 rounded-lg px-3 sm:px-4 py-2 text-sm text-slate-600 focus:outline-none focus:ring-2 focus:ring-violet-500"
            whileHover={{ scale: 1.02 }}
            whileFocus={{ scale: 1.02 }}
          >
            <option value="all">All Locations</option>
            <option value="nearby">Nearby</option>
            <option value="city">My City</option>
          </motion.select>
        </motion.div>
        
        <motion.div 
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {listings.map((listing, index) => (
            <motion.div 
              key={listing.id} 
              className="bg-white rounded-xl sm:rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all group border border-violet-100 hover:border-violet-200"
              variants={cardVariants}
              whileHover={{ y: -8, transition: { duration: 0.3 } }}
            >
              <div className="relative overflow-hidden">
                <motion.img 
                  src={placeholderImages[index]} 
                  alt={listing.title}
                  className="w-full h-48 sm:h-48 object-cover"
                  whileHover={{ scale: 1.1 }}
                  transition={{ duration: 0.4 }}
                />
                <motion.div 
                  className="absolute top-3 left-3"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <span className="bg-gradient-to-r from-violet-500 to-purple-600 text-white text-xs font-medium px-2 py-1 rounded-full">
                    {listing.condition}
                  </span>
                </motion.div>
                <motion.div 
                  className="absolute top-3 right-3"
                  whileHover={{ scale: 1.2 }}
                >
                  <button className="w-8 h-8 bg-white/80 backdrop-blur rounded-full flex items-center justify-center hover:bg-white transition-colors">
                    <svg className="w-4 h-4 text-violet-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                    </svg>
                  </button>
                </motion.div>
              </div>
              
              <div className="p-3 sm:p-4">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-slate-800 group-hover:text-violet-600 transition-colors truncate">
                      {listing.title}
                    </h3>
                    <p className="text-sm text-slate-500 truncate">{listing.brand}</p>
                  </div>
                  <motion.span 
                    className="text-violet-600 font-bold ml-2"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                  >
                    ${listing.value}
                  </motion.span>
                </div>
                
                <div className="flex items-center gap-2 mb-3 sm:mb-4 flex-wrap">
                  <span className="text-xs bg-violet-50 text-violet-700 px-2 py-1 rounded">
                    Size {listing.size}
                  </span>
                  <span className="text-xs bg-violet-50 text-violet-700 px-2 py-1 rounded">
                    {listing.category}
                  </span>
                </div>
                
                <div className="flex items-center gap-2 mb-3 sm:mb-4">
                  <img 
                    src={`https://ui-avatars.com/api/?name=${listing.owner}&background=c4b5fd&color=5b21b6&bold=true`}
                    alt={listing.owner}
                    className="w-5 h-5 sm:w-6 sm:h-6 rounded-full"
                  />
                  <span className="text-xs sm:text-sm text-slate-600 truncate">{listing.owner}</span>
                  <span className="text-xs text-slate-400">• {listing.distance}</span>
                </div>
                
                <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                  <Button 
                    onClick={() => setSelectedListing(listing.id)}
                    className="w-full bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700 text-white text-sm"
                  >
                    Request Swap
                  </Button>
                </motion.div>
              </div>
            </motion.div>
          ))}
        </motion.div>
        
        <motion.div 
          className="text-center mt-8 sm:mt-10"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button variant="outline" className="px-6 sm:px-8 border-violet-200 text-violet-700 hover:bg-violet-50">
              Load More Items
            </Button>
          </motion.div>
        </motion.div>
        
        <AnimatePresence>
          {selectedListing && (
            <SwapRequestModal 
              listingId={selectedListing}
              onClose={() => setSelectedListing(null)}
            />
          )}
        </AnimatePresence>
      </div>
    </motion.section>
  );
}