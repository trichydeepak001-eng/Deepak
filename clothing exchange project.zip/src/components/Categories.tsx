export function Categories() {
  const categories = [
    { name: "Tops", count: 234, icon: "👕" },
    { name: "Bottoms", count: 189, icon: "👖" },
    { name: "Dresses", count: 156, icon: "👗" },
    { name: "Outerwear", count: 98, icon: "🧥" },
    { name: "Shoes", count: 145, icon: "👟" },
    { name: "Accessories", count: 267, icon: "👜" },
  ];

  return (
    <section className="py-12 bg-slate-100">
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-2xl font-bold text-slate-800 mb-6">Browse by Category</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories.map((cat) => (
            <button
              key={cat.name}
              className="bg-white rounded-2xl p-6 text-center hover:shadow-lg transition-shadow group"
            >
              <span className="text-4xl mb-3 block">{cat.icon}</span>
              <h3 className="font-semibold text-slate-800 group-hover:text-emerald-600 transition-colors">
                {cat.name}
              </h3>
              <p className="text-sm text-slate-500 mt-1">{cat.count} items</p>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}