import { motion } from "framer-motion";
import type { View } from "../App";

interface NavbarProps {
  currentView: View;
  setCurrentView: (view: View) => void;
  onAddListing: () => void;
  user: { name: string; email: string; avatar: string } | null;
  onLogout: () => void;
}

export function Navbar({ currentView, setCurrentView, onAddListing, user, onLogout }: NavbarProps) {
  const navItems = [
    { id: "home" as View, label: "Home" },
    { id: "browse" as View, label: "Browse" },
    { id: "swaps" as View, label: "My Swaps" },
    { id: "profile" as View, label: "Profile" },
  ];

  return (
    <motion.nav
      className="sticky top-0 z-40 bg-white/5 backdrop-blur-xl border-b border-white/10"
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ type: "spring", stiffness: 100 }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          <motion.div
            className="flex items-center gap-2 cursor-pointer"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setCurrentView("home")}
          >
            <motion.div
              className="w-10 h-10 bg-gradient-to-br from-violet-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg"
              whileHover={{ rotate: 180 }}
              transition={{ duration: 0.5 }}
            >
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
              </svg>
            </motion.div>
            <span className="text-xl font-bold text-white">
              SwapStyle
            </span>
          </motion.div>

          <div className="hidden sm:flex items-center gap-1">
            {navItems.map((item, index) => (
              <motion.button
                key={item.id}
                onClick={() => setCurrentView(item.id)}
                className={`px-4 py-2 rounded-xl text-sm font-medium transition-all relative ${
                  currentView === item.id
                    ? "text-white"
                    : "text-white/60 hover:text-white hover:bg-white/10"
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                {currentView === item.id && (
                  <motion.div
                    className="absolute inset-0 bg-white/20 backdrop-blur-sm rounded-xl border border-white/30"
                    layoutId="activeTab"
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  />
                )}
                <span className="relative z-10">{item.label}</span>
              </motion.button>
            ))}
          </div>

          <div className="flex items-center gap-3">
            <motion.button
              onClick={onAddListing}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-medium rounded-xl shadow-lg"
              whileHover={{ scale: 1.05, boxShadow: "0 10px 40px rgba(16, 185, 129, 0.4)" }}
              whileTap={{ scale: 0.95 }}
            >
              <motion.svg
                className="w-5 h-5"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                animate={{ rotate: [0, 90, 0] }}
                transition={{ duration: 0.5 }}
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </motion.svg>
              <span className="hidden sm:inline">Add Listing</span>
            </motion.button>

            <motion.div
              className="flex items-center gap-2 cursor-pointer group"
              whileHover={{ scale: 1.02 }}
              onClick={onLogout}
            >
              <motion.img
                src={user?.avatar}
                alt={user?.name}
                className="w-9 h-9 rounded-full object-cover border-2 border-white/30 group-hover:border-white/60 transition-colors"
                whileHover={{ rotate: 360 }}
                transition={{ duration: 0.5 }}
              />
            </motion.div>
          </div>
        </div>

        <motion.div
          className="sm:hidden flex items-center gap-1 pb-3 overflow-x-auto"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          {navItems.map((item) => (
            <motion.button
              key={item.id}
              onClick={() => setCurrentView(item.id)}
              className={`px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all ${
                currentView === item.id
                  ? "bg-white/20 backdrop-blur-sm text-white border border-white/30"
                  : "text-white/60 bg-white/5"
              }`}
              whileTap={{ scale: 0.98 }}
            >
              {item.label}
            </motion.button>
          ))}
        </motion.div>
      </div>
    </motion.nav>
  );
}