import { motion } from "framer-motion";
import type { ClothingItem } from "../data/clothes";

interface ClothingCardProps {
  item: ClothingItem;
  index: number;
  onRequestSwap: (item: ClothingItem) => void;
  isOwnItem?: boolean;
}

export function ClothingCard({ item, index, onRequestSwap, isOwnItem = false }: ClothingCardProps) {
  return (
    <motion.div
      className="group bg-white/80 backdrop-blur-sm rounded-2xl overflow-hidden border border-violet-100 hover:border-violet-300 transition-all shadow-lg hover:shadow-xl"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.05 }}
      whileHover={{ y: -5 }}
    >
      <div className="relative aspect-[3/4] overflow-hidden">
        <img
          src={item.image}
          alt={item.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />

        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

        {!isOwnItem && (
          <motion.button
            onClick={() => onRequestSwap(item)}
            className="absolute bottom-4 left-4 right-4 py-2.5 bg-gradient-to-r from-violet-500 to-purple-600 text-white font-medium rounded-xl opacity-0 group-hover:opacity-100 transition-all shadow-lg"
            initial={{ y: 20 }}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            Request Swap
          </motion.button>
        )}

        {isOwnItem && (
          <div className="absolute bottom-4 left-4 right-4 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-medium rounded-xl text-center shadow-lg">
            Your Listing
          </div>
        )}

        <div className="absolute top-3 left-3">
          <span className="px-2.5 py-1 bg-white/90 backdrop-blur-sm rounded-lg text-xs font-medium text-slate-700 shadow-sm">
            {item.condition}
          </span>
        </div>

        <motion.button
          className="absolute top-3 right-3 w-8 h-8 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center shadow-sm hover:bg-rose-50 transition-colors"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
        >
          <svg className="w-4 h-4 text-rose-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
          </svg>
        </motion.button>
      </div>

      <div className="p-4">
        <div className="flex items-start justify-between gap-2 mb-2">
          <div>
            <h3 className="font-semibold text-slate-800 line-clamp-1">{item.title}</h3>
            <p className="text-sm text-slate-500">{item.brand}</p>
          </div>
          <div className="text-right">
            <p className="text-sm font-medium text-emerald-600">${item.estimatedValue}</p>
            <p className="text-xs text-slate-400">est. value</p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-500">
          <span className="px-2 py-0.5 bg-violet-50 rounded-md">{item.size}</span>
          <span>-</span>
          <span className="flex items-center gap-1">
            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            {item.location}
          </span>
        </div>

        <div className="flex items-center gap-2 mt-3 pt-3 border-t border-violet-100">
          <img
            src={item.owner.avatar}
            alt={item.owner.name}
            className="w-6 h-6 rounded-full object-cover"
          />
          <span className="text-xs text-slate-500">{item.owner.name}</span>
        </div>
      </div>
    </motion.div>
  );
}