import { useState } from "react";
import { motion } from "framer-motion";

interface SwapModalProps {
  item: {
    id: number;
    title: string;
    brand: string;
    estimatedValue: number;
    image: string;
    owner: { name: string; avatar: string };
  };
  myItems: {
    id: number;
    title: string;
    brand: string;
    estimatedValue: number;
    image: string;
  }[];
  onClose: () => void;
  onSend: (myItem: typeof myItems[0], message: string) => void;
}

export function SwapModal({ item, myItems, onClose, onSend }: SwapModalProps) {
  const [selectedItem, setSelectedItem] = useState<typeof myItems[0] | null>(null);
  const [message, setMessage] = useState("");

  const valueDiff = selectedItem ? item.estimatedValue - selectedItem.estimatedValue : 0;

  return (
    <motion.div
      className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
    >
      <motion.div
        className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b border-slate-200">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-slate-800">Request Swap</h2>
            <button
              onClick={onClose}
              className="w-10 h-10 rounded-full hover:bg-slate-100 flex items-center justify-center transition-colors"
            >
              <svg className="w-5 h-5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        <div className="p-6">
          {/* Their Item */}
          <div className="mb-6">
            <h3 className="text-sm font-medium text-slate-500 mb-3">You want:</h3>
            <div className="flex items-center gap-4 p-4 bg-violet-50 rounded-xl border border-violet-100">
              <img
                src={item.image}
                alt={item.title}
                className="w-20 h-24 rounded-lg object-cover"
              />
              <div className="flex-1">
                <h4 className="font-semibold text-slate-800">{item.title}</h4>
                <p className="text-sm text-slate-500">{item.brand}</p>
                <div className="flex items-center gap-2 mt-2">
                  <img
                    src={item.owner.avatar}
                    alt={item.owner.name}
                    className="w-5 h-5 rounded-full"
                  />
                  <span className="text-xs text-slate-500">{item.owner.name}</span>
                </div>
              </div>
              <div className="text-right">
                <p className="text-lg font-bold text-emerald-600">${item.estimatedValue}</p>
                <p className="text-xs text-slate-400">est. value</p>
              </div>
            </div>
          </div>

          {/* Your Items */}
          <div className="mb-6">
            <h3 className="text-sm font-medium text-slate-500 mb-3">Select your item to offer:</h3>
            <div className="grid grid-cols-2 gap-3">
              {myItems.map((myItem) => (
                <motion.button
                  key={myItem.id}
                  onClick={() => setSelectedItem(myItem)}
                  className={`p-3 rounded-xl border-2 text-left transition-all ${
                    selectedItem?.id === myItem.id
                      ? "border-violet-500 bg-violet-50"
                      : "border-slate-200 hover:border-violet-300"
                  }`}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <div className="flex gap-3">
                    <img
                      src={myItem.image}
                      alt={myItem.title}
                      className="w-14 h-16 rounded-lg object-cover"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-slate-800 text-sm truncate">{myItem.title}</h4>
                      <p className="text-xs text-slate-500">{myItem.brand}</p>
                      <p className="text-sm font-semibold text-emerald-600 mt-1">
                        ${myItem.estimatedValue}
                      </p>
                    </div>
                  </div>
                </motion.button>
              ))}
            </div>
          </div>

          {/* Value Comparison */}
          {selectedItem && (
            <motion.div
              className="mb-6 p-4 rounded-xl border border-slate-200 bg-slate-50"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <div className="flex items-center justify-between">
                <div className="text-center">
                  <p className="text-xs text-slate-500">Their Item</p>
                  <p className="text-xl font-bold text-violet-600">${item.estimatedValue}</p>
                </div>
                <div className="flex-1 mx-4">
                  <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        Math.abs(valueDiff) <= 10
                          ? "bg-emerald-500"
                          : "bg-amber-500"
                      }`}
                      style={{ width: `${Math.min(100, 100 - Math.abs(valueDiff))}%` }}
                    />
                  </div>
                </div>
                <div className="text-center">
                  <p className="text-xs text-slate-500">Your Item</p>
                  <p className="text-xl font-bold text-purple-600">${selectedItem.estimatedValue}</p>
                </div>
              </div>
              <p className={`text-center text-sm mt-2 ${
                Math.abs(valueDiff) <= 10 ? "text-emerald-600" : "text-amber-600"
              }`}>
                {Math.abs(valueDiff) <= 10
                  ? "Great match! Values are close."
                  : `Value difference: $${Math.abs(valueDiff)}`}
              </p>
            </motion.div>
          )}

          {/* Message */}
          <div className="mb-6">
            <h3 className="text-sm font-medium text-slate-500 mb-2">Add a message (optional):</h3>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Introduce yourself and explain why you'd like to swap..."
              className="w-full p-3 border border-slate-200 rounded-xl resize-none focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-transparent"
              rows={3}
            />
          </div>

          {/* Actions */}
          <div className="flex gap-3">
            <motion.button
              onClick={onClose}
              className="flex-1 py-3 border border-slate-200 text-slate-700 font-medium rounded-xl hover:bg-slate-50 transition-colors"
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.99 }}
            >
              Cancel
            </motion.button>
            <motion.button
              onClick={() => selectedItem && onSend(selectedItem, message)}
              disabled={!selectedItem}
              className={`flex-1 py-3 font-medium rounded-xl transition-all ${
                selectedItem
                  ? "bg-gradient-to-r from-violet-500 to-purple-600 text-white shadow-lg shadow-purple-200"
                  : "bg-slate-100 text-slate-400 cursor-not-allowed"
              }`}
              whileHover={selectedItem ? { scale: 1.01 } : {}}
              whileTap={selectedItem ? { scale: 0.99 } : {}}
            >
              Send Swap Request
            </motion.button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}