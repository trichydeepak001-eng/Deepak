import { useState } from "react";
import { Button } from "./ui/button";

interface ChatPanelProps {
  onClose: () => void;
  swapId: number;
}

export function ChatPanel({ onClose, swapId }: ChatPanelProps) {
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState([
    { id: 1, sender: "them", text: "Hi! I'm interested in your Vintage Band Tee. Is it still available?", time: "2:30 PM" },
    { id: 2, sender: "me", text: "Yes, it's still available! Would you like to swap for the Denim Jacket?", time: "2:32 PM" },
    { id: 3, sender: "them", text: "That sounds great! The jacket is in excellent condition. When would you like to meet?", time: "2:35 PM" },
  ]);

  const handleSend = () => {
    if (message.trim()) {
      setMessages([...messages, { 
        id: messages.length + 1, 
        sender: "me", 
        text: message, 
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }]);
      setMessage("");
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end md:items-center justify-center md:p-4">
      <div className="bg-white md:rounded-2xl w-full md:max-w-lg h-[80vh] md:h-[600px] flex flex-col">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img 
              src="https://ui-avatars.com/api/?name=Sarah+M&background=c4b5fd&color=5b21b6&bold=true"
              alt="Sarah M."
              className="w-10 h-10 rounded-full"
            />
            <div>
              <h3 className="font-semibold text-slate-800">Sarah M.</h3>
              <p className="text-xs text-emerald-500">Online</p>
            </div>
          </div>
          <button onClick={onClose} className="w-10 h-10 rounded-full hover:bg-slate-100 flex items-center justify-center">
            <svg className="w-5 h-5 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((msg) => (
            <div key={msg.id} className={`flex ${msg.sender === "me" ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[80%] ${msg.sender === "me" ? "bg-emerald-500 text-white" : "bg-slate-100 text-slate-800"} rounded-2xl px-4 py-2`}>
                <p className="text-sm">{msg.text}</p>
                <p className={`text-xs mt-1 ${msg.sender === "me" ? "text-emerald-100" : "text-slate-400"}`}>{msg.time}</p>
              </div>
            </div>
          ))}
        </div>
        
        <div className="p-4 border-t border-slate-200">
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Type a message..."
              className="flex-1 px-4 py-2 border border-slate-200 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              onKeyPress={(e) => e.key === "Enter" && handleSend()}
            />
            <Button onClick={handleSend} className="bg-emerald-500 hover:bg-emerald-600 rounded-full w-10 h-10 p-0">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
              </svg>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}