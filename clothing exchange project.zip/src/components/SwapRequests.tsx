import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

interface SwapRequest {
  id: number;
  status: "pending" | "accepted" | "declined" | "completed";
  theirItem: {
    title: string;
    image: string;
    owner: string;
    avatar: string;
  };
  myItem: {
    title: string;
    image: string;
  };
  date: string;
  message?: string;
}

export function SwapRequests() {
  const [activeTab, setActiveTab] = useState<"all" | "incoming" | "outgoing">("all");

  const swapRequests: SwapRequest[] = [
    {
      id: 1,
      status: "pending",
      theirItem: {
        title: "Vintage Denim Jacket",
        image: "https://images.unsplash.com/photo-1576995853080-3b6de5a87d22?w=400&h=500&fit=crop",
        owner: "Sarah Miller",
        avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
      },
      myItem: {
        title: "Summer Floral Dress",
        image: "https://images.unsplash.com/photo-1572804013309-59a88f240654?w=400&h=500&fit=crop",
      },
      date: "2 hours ago",
      message: "Would love to swap! My jacket is in great condition.",
    },
    {
      id: 2,
      status: "accepted",
      theirItem: {
        title: "Wool Sweater",
        image: "https://images.unsplash.com/photo-1576566588028-4147f3882f37?w=400&h=500&fit=crop",
        owner: "Emma Wilson",
        avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
      },
      myItem: {
        title: "Leather Boots",
        image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=500&fit=crop",
      },
      date: "Yesterday",
    },
    {
      id: 3,
      status: "completed",
      theirItem: {
        title: "Silk Scarf",
        image: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=400&h=500&fit=crop",
        owner: "Lisa Chen",
        avatar: "https://images.unsplash.com/photo-1544005313-94ddf02805df?w=100&h=100&fit=crop",
      },
      myItem: {
        title: "Cotton T-Shirt",
        image: "https://images.unsplash.com/photo-1521572163470-46589b1c5a53?w=400&h=500&fit=crop",
      },
      date: "3 days ago",
    },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-amber-100 text-amber-700 border-amber-200";
      case "accepted":
        return "bg-emerald-100 text-emerald-700 border-emerald-200";
      case "declined":
        return "bg-rose-100 text-rose-700 border-rose-200";
      case "completed":
        return "bg-blue-100 text-blue-700 border-blue-200";
      default:
        return "bg-slate-100 text-slate-700 border-slate-200";
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-slate-800">My Swaps</h1>
          
          {/* Tabs */}
          <div className="flex bg-white/80 backdrop-blur-sm rounded-xl p-1 border border-violet-100">
            {[
              { id: "all", label: "All" },
              { id: "incoming", label: "Incoming" },
              { id: "outgoing", label: "Outgoing" },
            ].map((tab) => (
              <motion.button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as "all" | "incoming" | "outgoing")}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  activeTab === tab.id
                    ? "bg-gradient-to-r from-violet-500 to-purple-600 text-white shadow-md"
                    : "text-slate-600 hover:bg-violet-50"
                }`}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                {tab.label}
              </motion.button>
            ))}
          </div>
        </div>

        {/* Swap Cards */}
        <div className="space-y-4">
          <AnimatePresence>
            {swapRequests.map((request, index) => (
              <motion.div
                key={request.id}
                className="bg-white/80 backdrop-blur-sm rounded-2xl border border-violet-100 overflow-hidden shadow-lg"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ delay: index * 0.1 }}
              >
                <div className="p-4 sm:p-6">
                  {/* Status and Date */}
                  <div className="flex items-center justify-between mb-4">
                    <span className={`px-3 py-1 rounded-lg text-xs font-medium border ${getStatusColor(request.status)}`}>
                      {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
                    </span>
                    <span className="text-sm text-slate-500">{request.date}</span>
                  </div>

                  {/* Items */}
                  <div className="flex items-center gap-4">
                    {/* Their Item */}
                    <div className="flex-1">
                      <p className="text-xs text-slate-500 mb-2">Their Item</p>
                      <div className="flex items-center gap-3">
                        <img
                          src={request.theirItem.image}
                          alt={request.theirItem.title}
                          className="w-16 h-20 rounded-lg object-cover"
                        />
                        <div>
                          <p className="font-medium text-slate-800 text-sm">{request.theirItem.title}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <img
                              src={request.theirItem.avatar}
                              alt={request.theirItem.owner}
                              className="w-5 h-5 rounded-full"
                            />
                            <span className="text-xs text-slate-500">{request.theirItem.owner}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Swap Icon */}
                    <div className="flex-shrink-0">
                      <motion.div
                        className="w-10 h-10 bg-gradient-to-br from-violet-500 to-purple-600 rounded-full flex items-center justify-center shadow-lg shadow-purple-200"
                        animate={{ rotate: [0, 180, 360] }}
                        transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                      >
                        <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
                        </svg>
                      </motion.div>
                    </div>

                    {/* My Item */}
                    <div className="flex-1">
                      <p className="text-xs text-slate-500 mb-2">My Item</p>
                      <div className="flex items-center gap-3">
                        <img
                          src={request.myItem.image}
                          alt={request.myItem.title}
                          className="w-16 h-20 rounded-lg object-cover"
                        />
                        <p className="font-medium text-slate-800 text-sm">{request.myItem.title}</p>
                      </div>
                    </div>
                  </div>

                  {/* Message */}
                  {request.message && (
                    <div className="mt-4 p-3 bg-violet-50 rounded-xl border border-violet-100">
                      <p className="text-sm text-slate-600">
                        <span className="font-medium text-violet-700">Message:</span>{" "}
                        {request.message}
                      </p>
                    </div>
                  )}

                  {/* Actions */}
                  {request.status === "pending" && (
                    <div className="flex gap-3 mt-4">
                      <motion.button
                        className="flex-1 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-medium rounded-xl shadow-lg shadow-emerald-200"
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        Accept
                      </motion.button>
                      <motion.button
                        className="flex-1 py-2.5 border border-rose-200 text-rose-600 font-medium rounded-xl hover:bg-rose-50"
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        Decline
                      </motion.button>
                      <motion.button
                        className="py-2.5 px-4 border border-violet-200 text-violet-600 font-medium rounded-xl hover:bg-violet-50"
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                        </svg>
                      </motion.button>
                    </div>
                  )}

                  {request.status === "accepted" && (
                    <div className="flex gap-3 mt-4">
                      <motion.button
                        className="flex-1 py-2.5 bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-medium rounded-xl shadow-lg shadow-blue-200"
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        Arrange Pickup
                      </motion.button>
                      <motion.button
                        className="py-2.5 px-4 border border-violet-200 text-violet-600 font-medium rounded-xl hover:bg-violet-50"
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                        </svg>
                      </motion.button>
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {swapRequests.length === 0 && (
          <motion.div
            className="text-center py-16"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <div className="w-20 h-20 bg-gradient-to-br from-violet-100 to-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-10 h-10 text-violet-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
              </svg>
            </div>
            <h3 className="text-lg font-semibold text-slate-800 mb-2">No swap requests yet</h3>
            <p className="text-slate-500">Start browsing to find items you'd like to swap!</p>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
}