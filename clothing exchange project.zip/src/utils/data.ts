export interface Listing {
  id: number;
  title: string;
  brand: string;
  category: string;
  size: string;
  condition: string;
  value: number;
  owner: string;
  distance: string;
}

export interface SwapRequest {
  id: number;
  myItem: string;
  theirItem: string;
  user: string;
  time: string;
  status: "pending" | "accepted" | "completed";
  valueDiff: number;
}

export const listings: Listing[] = [
  {
    id: 1,
    title: "Vintage Denim Jacket",
    brand: "Levi's",
    category: "Outerwear",
    size: "M",
    condition: "Excellent",
    value: 45,
    owner: "Sarah M.",
    distance: "2.3 mi"
  },
  {
    id: 2,
    title: "Floral Summer Dress",
    brand: "Zara",
    category: "Dresses",
    size: "S",
    condition: "Like New",
    value: 35,
    owner: "Emma K.",
    distance: "1.5 mi"
  },
  {
    id: 3,
    title: "Wool Blend Sweater",
    brand: "H&M",
    category: "Tops",
    size: "L",
    condition: "Good",
    value: 25,
    owner: "Mike R.",
    distance: "3.8 mi"
  },
  {
    id: 4,
    title: "High-Waist Jeans",
    brand: "Madewell",
    category: "Bottoms",
    size: "28",
    condition: "Excellent",
    value: 55,
    owner: "Lisa T.",
    distance: "0.8 mi"
  },
  {
    id: 5,
    title: "Canvas Sneakers",
    brand: "Converse",
    category: "Shoes",
    size: "9",
    condition: "Good",
    value: 30,
    owner: "David L.",
    distance: "4.2 mi"
  },
  {
    id: 6,
    title: "Leather Crossbody Bag",
    brand: "Coach",
    category: "Accessories",
    size: "One Size",
    condition: "Like New",
    value: 65,
    owner: "Jenny W.",
    distance: "2.1 mi"
  },
  {
    id: 7,
    title: "Striped Button-Up",
    brand: "J.Crew",
    category: "Tops",
    size: "M",
    condition: "Excellent",
    value: 28,
    owner: "Alex P.",
    distance: "1.9 mi"
  },
  {
    id: 8,
    title: "Pleated Midi Skirt",
    brand: "& Other Stories",
    category: "Bottoms",
    size: "S",
    condition: "New",
    value: 40,
    owner: "Rachel G.",
    distance: "3.1 mi"
  }
];

export const swapRequests: SwapRequest[] = [
  {
    id: 1,
    myItem: "Vintage Band Tee",
    theirItem: "Denim Jacket",
    user: "Sarah M.",
    time: "2 hours ago",
    status: "pending",
    valueDiff: 5
  },
  {
    id: 2,
    myItem: "Wool Sweater",
    theirItem: "Summer Dress",
    user: "Emma K.",
    time: "1 day ago",
    status: "accepted",
    valueDiff: -10
  },
  {
    id: 3,
    myItem: "Canvas Sneakers",
    theirItem: "Boots",
    user: "Mike R.",
    time: "3 days ago",
    status: "completed",
    valueDiff: 0
  },
  {
    id: 4,
    myItem: "Silk Blouse",
    theirItem: "Cardigan",
    user: "Lisa T.",
    time: "5 hours ago",
    status: "pending",
    valueDiff: 15
  }
];