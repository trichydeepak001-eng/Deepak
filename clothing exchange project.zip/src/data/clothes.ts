export interface ClothingItem {
  id: number;
  title: string;
  brand: string;
  category: string;
  size: string;
  condition: string;
  estimatedValue: number;
  image: string;
  location: string;
  owner: {
    name: string;
    avatar: string;
  };
}

export const clothingItems: ClothingItem[] = [
  {
    id: 1,
    title: "Vintage Denim Jacket",
    brand: "Levi's",
    category: "Outerwear",
    size: "M",
    condition: "Like New",
    estimatedValue: 45,
    image: "https://images.unsplash.com/photo-1576995853080-3b6de5a87d22?w=400&h=500&fit=crop",
    location: "Brooklyn, NY",
    owner: {
      name: "Sarah Miller",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
    },
  },
  {
    id: 2,
    title: "Summer Floral Dress",
    brand: "Zara",
    category: "Dresses",
    size: "S",
    condition: "New with Tags",
    estimatedValue: 35,
    image: "https://images.unsplash.com/photo-1572804013309-59a88f240654?w=400&h=500&fit=crop",
    location: "Manhattan, NY",
    owner: {
      name: "Emma Wilson",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
    },
  },
  {
    id: 3,
    title: "Wool Blend Sweater",
    brand: "H&M",
    category: "Tops",
    size: "L",
    condition: "Good",
    estimatedValue: 25,
    image: "https://images.unsplash.com/photo-1576566588028-4147f3882f37?w=400&h=500&fit=crop",
    location: "Queens, NY",
    owner: {
      name: "Mike Johnson",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
    },
  },
  {
    id: 4,
    title: "Classic Leather Boots",
    brand: "Dr. Martens",
    category: "Shoes",
    size: "8",
    condition: "Like New",
    estimatedValue: 65,
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=500&fit=crop",
    location: "Brooklyn, NY",
    owner: {
      name: "Lisa Chen",
      avatar: "https://images.unsplash.com/photo-1544005313-94ddf02805df?w=100&h=100&fit=crop",
    },
  },
  {
    id: 5,
    title: "Silk Scarf Collection",
    brand: "Hermes",
    category: "Accessories",
    size: "One Size",
    condition: "Good",
    estimatedValue: 120,
    image: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=400&h=500&fit=crop",
    location: "Manhattan, NY",
    owner: {
      name: "Anna Martinez",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop",
    },
  },
  {
    id: 6,
    title: "Cotton T-Shirt Bundle",
    brand: "Uniqlo",
    category: "Tops",
    size: "M",
    condition: "Good",
    estimatedValue: 20,
    image: "https://images.unsplash.com/photo-1521572163470-46589b1c5a53?w=400&h=500&fit=crop",
    location: "Bronx, NY",
    owner: {
      name: "David Park",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop",
    },
  },
  {
    id: 7,
    title: "High-Waist Jeans",
    brand: "Madewell",
    category: "Bottoms",
    size: "28",
    condition: "Like New",
    estimatedValue: 40,
    image: "https://images.unsplash.com/photo-1541099697506-228536275f53?w=400&h=500&fit=crop",
    location: "Brooklyn, NY",
    owner: {
      name: "Jessica Brown",
      avatar: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=100&h=100&fit=crop",
    },
  },
  {
    id: 8,
    title: "Canvas Sneakers",
    brand: "Converse",
    category: "Shoes",
    size: "9",
    condition: "Good",
    estimatedValue: 30,
    image: "https://images.unsplash.com/photo-1607528845035-c36e7a6fb66d?w=400&h=500&fit=crop",
    location: "Queens, NY",
    owner: {
      name: "Tom Wilson",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop",
    },
  },
];

export const myItems: ClothingItem[] = [
  {
    id: 101,
    title: "Summer Floral Dress",
    brand: "Zara",
    category: "Dresses",
    size: "S",
    condition: "New with Tags",
    estimatedValue: 35,
    image: "https://images.unsplash.com/photo-1572804013309-59a88f240654?w=400&h=500&fit=crop",
    location: "Manhattan, NY",
    owner: {
      name: "You",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop",
    },
  },
  {
    id: 102,
    title: "Leather Boots",
    brand: "Dr. Martens",
    category: "Shoes",
    size: "8",
    condition: "Like New",
    estimatedValue: 55,
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=500&fit=crop",
    location: "Brooklyn, NY",
    owner: {
      name: "You",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop",
    },
  },
  {
    id: 103,
    title: "Cotton T-Shirt",
    brand: "Uniqlo",
    category: "Tops",
    size: "M",
    condition: "Good",
    estimatedValue: 18,
    image: "https://images.unsplash.com/photo-1521572163470-46589b1c5a53?w=400&h=500&fit=crop",
    location: "Bronx, NY",
    owner: {
      name: "You",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop",
    },
  },
];